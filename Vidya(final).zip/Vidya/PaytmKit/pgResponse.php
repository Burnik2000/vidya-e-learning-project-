<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

// include("../database/controllerUserData.php");
include("../database/connection.php");
session_start();


// following files need to be included
require_once("./lib/config_paytm.php");
require_once("./lib/encdec_paytm.php");

$paytmChecksum = "";
$paramList = array();
$isValidChecksum = "FALSE";

$paramList = $_POST;
$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; //Sent by Paytm pg

//Verify all parameters received from Paytm pg to your application. Like MID received from paytm pg is same as your application�s MID, TXN_AMOUNT and ORDER_ID are same as what was sent by you to Paytm PG for initiating transaction etc.
$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); //will return TRUE or FALSE string.


if($isValidChecksum == "TRUE") {
	//echo "<b>Checksum matched and following are the transaction details:</b>" . "<br/>";
	if ($_POST["STATUS"] == "TXN_SUCCESS") {
		echo "<p style='font-size:3rem;'><center>Transaction status is success</center></p>" . "<br/>";
		//Process your transaction here as success transaction.
		//Verify amount & order id received from Payment gateway with your application's order id and amount.


		if(isset($_POST['ORDERID']) && isset($_POST['TXNAMOUNT'])){
			$order_id = $_POST['ORDERID'];
			// $user_email = $_SESSION['email'];
			// $course_id = $_SESSION['course_id'];
			$status = $_POST['STATUS'];
			$respmsg = $_POST['RESPMSG'];
			$amount = $_POST['TXNAMOUNT'];
			$date = $_POST['TXNDATE'];

			
			$sql = "UPDATE `courseorder` SET status='$status', respmsg= '$respmsg', order_date='$date' where order_id='$order_id'";

			if($con->query($sql) == TRUE){
				echo"<p style='font-size:2rem;'><center>Redirecting to My Profile...</center></p>";

				if(!isset($_SESSION['email'])){
					// $row=mysqli_fetch_assoc(mysqli_query($con, "SELECT user_email FROM courseorder where order_id='$order_id';"));


					$sql = "SELECT user_email FROM courseorder where order_id='$order_id'";

					$result = mysqli_query($con, $sql) or die("query faild");

					$rows = mysqli_fetch_assoc($result);
					
					// $row = mysqli_fetch_assoc($res);
					$_SESSION['email']= $rows['user_email'];

					$user_email = $_SESSION['email'];
					// echo "$user_email";
				}



				echo "<script> setTimeout(() =>{
					window.location.href = '../user/user_course.php';}, 1500); </script>";
			}
		}



	}
	else {
		echo "<b>Transaction status is failure</b>" . "<br/>";
	}

	if (isset($_POST) && count($_POST)>0 )
	{ 
		// foreach($_POST as $paramName => $paramValue) {
		// 		echo "<br/>" . $paramName . " = " . $paramValue;
		// }
	}
	

}
else {
	echo "<b>Checksum mismatched.</b>";
	//Process transaction as suspicious.
}

?>