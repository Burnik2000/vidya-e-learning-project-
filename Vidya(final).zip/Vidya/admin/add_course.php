<?php 

    if(!isset($_SESSION)){
        session_start();
    }
  
    if(isset($_SESSION['is_admin_login'])){
        $adminEmail = $_SESSION['admin'];
        }else{
        header('location:../index.php');
        }

    include('admindata/course_db.php');

    // checking for entry 
    if(isset($_REQUEST['submit_course'])){

       if(
        ($_REQUEST['course_name'] == "") ||
        ($_REQUEST['course_desc'] == "") || 
        ($_REQUEST['author_name'] == "") || 
        ($_REQUEST['course_language'] == "") || 
        ($_REQUEST['course_duration'] == "") || 
        ($_REQUEST['course_original_price'] == "") || 
        ($_REQUEST['course_quiz'] == "") || 
        ($_REQUEST['course_selling_price'] == "")
        ){
            $msg = '<div class="fill_error">Fill All Fields</div>';
            echo '<meta http-equiv="refresh" content="0;URL=?fill_all_fields" />';
        }
        else {
             $course_name = $_REQUEST['course_name'];
             $course_desc = $_REQUEST['course_desc'];
             $author_name = $_REQUEST['author_name'];
             $course_language = $_REQUEST['course_language'];
             $course_duration = $_REQUEST['course_duration'];
             $course_original_price = $_REQUEST['course_original_price'];
             $course_selling_price = $_REQUEST['course_selling_price'];
             $course_quiz = $_REQUEST['course_quiz'];
             $course_image = $_FILES['course_img']['name'];
             $course_image_temp = $_FILES['course_img']['tmp_name'];
             $img_folder = '../img/course/'.$course_image;
             move_uploaded_file($course_image_temp, $img_folder);


             $sql = "INSERT INTO course (course_name, course_description, course_author, course_language, course_image, course_duration, course_selling_price, course_original_price, quiz_link) VALUES ('$course_name', '$course_desc', '$author_name', '$course_language', '$img_folder', '$course_duration',  '$course_selling_price', '$course_original_price', '$course_quiz')";


             if($conn->query($sql) == TRUE){
                $msg = '<div class="add_success">Course Added Succesfully</div>';
                echo '<meta http-equiv="refresh" content="0;URL=?Course_Added_Succesfully" />';
            }
            else{
                $msg = '<div class="fill_error">Unable to Add Course</div>';
                echo '<meta http-equiv="refresh" content="0;URL=?Unable_to_Add_Course" />';
            }
        }
    }
?>


<!DOCTYPE html>
<html>
<head>
	<title>Add New Course</title>
	<link rel="stylesheet" type="text/css" href="admin_css/add_course.css">
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <div class="add_course_main">
        <div class="add_course_head">Add New Course</div>
        <div class="add_course_upper">
            <form class="add_course_login" action="" method="POST" enctype="multipart/form-data">
                
                <input class="add_course_textbox form-control" type="text" id="course_name" name="course_name" placeholder="Type your course name here..." value="" required>
                
                <textarea class="add_course_textbox form-control" id="course_desc" name="course_desc" placeholder="Type your description here..." value="" required></textarea>
                
                <input class="add_course_textbox form-control" type="text" id="author_name" name="author_name" placeholder="Type author name here..." value="" required>

                <select class="add_course_textbox form-control" name="course_language" id="course_language" placeholder="Select language here..." required>
                    <option value="">Select language</option>
                    <option value="English">English</option>
                    <option value="Hindi">Hindi</option>
                    <option value="Bengali">Bengali</option>
                </select>

                <input class="add_course_textbox form-control" type="text" id="course_duration" name="course_duration" placeholder="Type course duration here..." value="" required>
                
                <input class="add_course_textbox form-control" type="text" id="course_original_price" name="course_original_price" placeholder="Type your original price here..." value="" required>
                
                <input class="add_course_textbox form-control" type="text" id="course_selling_price" name="course_selling_price" placeholder="Type your selling price here..." value="" required>
               
                <input class="add_course_textbox form-control" type="text" id="course_quiz" name="course_quiz" placeholder="Type your Quiz link here..." value="" required>

                <input type="file" class="add_course_textbox form-control" id="course_img" name="course_img" required>
                
                <input class="add_course_submit" type="submit" value="Add Course" name="submit_course">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>


</body>
</html>


