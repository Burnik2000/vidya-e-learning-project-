<?php 

    if(!isset($_SESSION)){
        session_start();
    }
  
    if(isset($_SESSION['is_admin_login'])){
        $adminEmail = $_SESSION['admin'];
        }else{
        header('location:../index.php');
        }

    include('admindata/course_db.php');

    // checking for entry 
    if(isset($_REQUEST['submit_lesson'])){

       if(
        ($_REQUEST['course_id'] == "") ||
        ($_REQUEST['course_name'] == "") || 
        ($_REQUEST['lesson_name'] == "") || 
        ($_REQUEST['lesson_desc'] == "")
        ){
            $msg = '<div class="fill_error">Fill All Fields</div>';
            echo '<meta http-equiv="refresh" content="0;URL=?fill_all_fields" />';
        }
        else {
             $course_id = $_REQUEST['course_id'];
             $course_name = $_REQUEST['course_name'];
             $lesson_name = $_REQUEST['lesson_name'];
             $lesson_desc = $_REQUEST['lesson_desc'];
             $lesson_video = $_FILES['lesson_video']['name'];
             $lesson_video_temp = $_FILES['lesson_video']['tmp_name'];
             $video_folder = '../lesson_video/'.$lesson_video;
             move_uploaded_file($lesson_video_temp, $video_folder);


             $sql = "INSERT INTO lesson (lesson_name, lesson_desc, lesson_link, course_id, course_name) VALUES ('$lesson_name', '$lesson_desc', '$video_folder', '$course_id', '$course_name')";


             if($conn->query($sql) == TRUE){
                $msg = '<div class="add_success">Lesson Added Succesfully</div>';
                echo '<meta http-equiv="refresh" content="0;URL=?Lesson_Added_Succesfully" />';
            }
            else{
                $msg = '<div class="fill_error">Unable to Add Lesson</div>';
                echo '<meta http-equiv="refresh" content="0;URL=?Unable_to_Add_Lesson" />';
            }
        }
    }
?>


<!DOCTYPE html>
<html>
<head>
	<title>Add New Lesson</title>
	<link rel="stylesheet" type="text/css" href="admin_css/add_lesson.css">
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <div class="add_lesson_main">
        <div class="add_lesson_head">Add New Lesson</div>
        <div class="add_lesson_upper">
            <form class="add_lesson_login" action="" method="POST" enctype="multipart/form-data">
                
                <input class="add_lesson_textbox form-control" type="text" id="course_id" name="course_id" placeholder="Type your course id here..." value="<?php if(isset($_SESSION['course_id'])) {echo $_SESSION['course_id'];} ?>" readonly>

                <input class="add_lesson_textbox form-control" type="text" id="course_name" name="course_name" placeholder="Type your course name here..." value="<?php if(isset($_SESSION['course_name'])) {echo $_SESSION['course_name'];} ?>" readonly>
                
                <input class="add_lesson_textbox form-control" type="text" id="lesson_name" name="lesson_name" placeholder="Type your lesson name here..." value="" required>
                
                <textarea class="add_lesson_textbox form-control" id="lesson_desc" name="lesson_desc" placeholder="Type your lesson description here..." value="" required></textarea>
               
                <input type="file" class="add_lesson_textbox form-control" id="lesson_video" name="lesson_video" required>
                
                <input class="add_lesson_submit" type="submit" value="Add Lesson" name="submit_lesson">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>


</body>
</html>


