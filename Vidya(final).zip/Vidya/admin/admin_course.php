<?php 
    if(!isset($_SESSION)){
      session_start();
    }
    
    if(isset($_SESSION['is_admin_login'])){
      $adminEmail = $_SESSION['admin'];
    }else{
      header('location:../index.php');
    }

    
    include('admindata/course_db.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Courses</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">

    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <!-- navbar -->
    
    <div class="admin_nav">
    <a href="admin_dashboard.php"> <div class="admin_navlink"> Dashboard </div></a>
    <a href="admin_course.php"> <div class="admin_navlink active"> Course </div></a>
    <a href="admin_lessons.php"><div class="admin_navlink"> Lessons </div></a>
    <a href="admin_student.php"><div class="admin_navlink"> Students </div></a>
    <a href="admin_sellreport.php"><div class="admin_navlink"> Sell Report </div></a>
    <a href="admin_payment.php"><div class="admin_navlink"> Payment Status </div></a>
    <a href="admin_feedback.php"><div class="admin_navlink"> Feedback </div></a>
    <a href="help_center.php"><div class="admin_navlink"> Help Center </div></a>
    <a href="admin_contact.php"><div class="admin_navlink"> <i class="fas fa-envelope"></i></div></a>
    <a href="admin_profile.php"><div class="admin_navlink"><i class="fas fa-user-circle"></i></div></a>
    <a href="admindata/logout.php"><div class="admin_navlink"> <i class="fas fa-sign-out-alt"></i> </div></a>
    </div>

<div class="mtop">
    <div class="dash_course_order">
        List Of Courses
    </div>
    </div>


    <?php 

    $sql = "SELECT * FROM course";
    $result = $conn->query($sql);
    if($result->num_rows > 0)
    {
    ?>

<!-- table -->

    <table class="table text-justify">
        <thead class="dash_table align-middle">
          <tr>
            <th scope="col">Course ID</th>
            <th scope="col">Name</th>
            <th scope="col">Description</th>
            <th scope="col">Author</th>
            <th scope="col">Language</th>
            <th scope="col">Image</th>
            <th scope="col">Duration</th>
            <th scope="col">Price (&#8377;)</th>
            <th scope="col">Original Price (&#8377;)</th>
            <th scope="col">Quiz</th>
            <th scope="col">Edit / Remove</th>
          </tr>
        </thead>
        <tbody>

        <?php  while($row = $result->fetch_assoc()){
           
          echo '<tr>';
          echo '<th scope="row">'.$row['course_id'].'</th>';
          echo '<td>'.$row['course_name'].'</td>';
          echo '<td class="desc_justify">'.$row['course_description'].'</td>';
          echo '<td>'.$row['course_author'].'</td>';
          echo '<td>'.$row['course_language'].'</td>';
          echo '<td><img style = "height:8rem;" src="'.$row['course_image'].'" alt="Image"></td>';
          echo '<td>'.$row['course_duration'].'</td>';
          echo '<td>&#8377;'.$row['course_selling_price'].'</td>';
          echo '<td>&#8377;'.$row['course_original_price'].'</td>';
          echo '<td><a target="_blank" style = "color:#000;" href="'.$row['quiz_link'].'"><i class="fas fa-pen"></i></a></td>';

          echo '<td>
                  <form action="edit_course.php" method="POST" class="d-inline" id="edit_form">
                     <input type="hidden" name="c_id" value='.$row["course_id"].'>
                     <button type="submit" name ="view" value="view" class="course_btn">
                     <a href="#" data-bs-toggle="modal" data-bs-target="#edit_course"><i class="fas fa-pen-square"></i></a></button>
                      </form>';


          echo '  <form method="POST" class="d-inline">
                    <input type="hidden" name="c_id" value='.$row["course_id"].'>
                    <button type="submit" name ="delete" value="delete" class="course_btn">
                        <i class="fas fa-trash-alt"></i></button>
                  </form>
                </td>';
          echo '</tr>';

          } ?>
        </tbody>
      </table>

      <?php  
    }
      else {
        echo "<div style='font-size:2rem; font-weight: bold; color: red'> <center>Please Add Course</center></div>";
      }
      ?>

      <p class="add_course"><a href="#" data-bs-toggle="modal" data-bs-target="#add_course"><i class="fas fa-plus-square"></i></a></p>


      <!-- course delete  -->

      <?php
        if(isset($_REQUEST['delete'])){
          $sql = "DELETE FROM course WHERE course_id = {$_REQUEST['c_id']}";
        
          if($conn->query($sql) == TRUE){
            echo '<meta http-equiv="refresh" content="0;URL=?deleted" />';
          } else {
            echo "Unable to Delete Data";
                        echo '<meta http-equiv="refresh" content="0;URL=?unable_to_delete" />';
          }
          }
        ?>

  <!-- add course -->

      <div class="modal fade" id="add_course" tabindex="-1" aria-labelledby="add_courseLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
              <?php include('add_course.php');?>
            </div>
          </div>
        </div>
      </div>

  <!-- edit course -->

      <div class="modal fade" id="edit_course" tabindex="-1" aria-labelledby="edit_courseLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
              <?php include('edit_course.php');?>
            </div>
          </div>
        </div>
      </div>

    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>