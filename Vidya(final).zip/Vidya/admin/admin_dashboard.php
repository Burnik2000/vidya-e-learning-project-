<?php
if(!isset($_SESSION)){
        session_start();
    }
  
    if(isset($_SESSION['is_admin_login'])){
        $adminEmail = $_SESSION['admin'];
        }else{
        header('location:../index.php');
        }

        include('admindata/course_db.php');


        $sql = "SELECT * from course";
        $result = $conn->query($sql);
        $totalcourse = $result->num_rows;

        $sql = "SELECT * from user";
        $result = $conn->query($sql);
        $totalstudent = $result->num_rows;

        $sql = "SELECT * from courseorder";
        $result = $conn->query($sql);
        $totalsold = $result->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">

    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">

</head>
<body>

    <!-- navbar -->
    
    <div class="admin_nav">
    <a href="admin_dashboard.php"> <div class="admin_navlink active"> Dashboard </div></a>
    <a href="admin_course.php"> <div class="admin_navlink"> Course </div></a>
    <a href="admin_lessons.php"><div class="admin_navlink"> Lessons </div></a>
    <a href="admin_student.php"><div class="admin_navlink"> Students </div></a>
    <a href="admin_sellreport.php"><div class="admin_navlink"> Sell Report </div></a>
    <a href="admin_payment.php"><div class="admin_navlink"> Payment Status </div></a>
    <a href="admin_feedback.php"><div class="admin_navlink"> Feedback </div></a>
    <a href="help_center.php"><div class="admin_navlink"> Help Center </div></a>
    <a href="admin_contact.php"><div class="admin_navlink"> <i class="fas fa-envelope"></i></div></a>
    <a href="admin_profile.php"><div class="admin_navlink"><i class="fas fa-user-circle"></i></div></a>
    <a href="admindata/logout.php"><div class="admin_navlink"> <i class="fas fa-sign-out-alt"></i> </div></a>
    </div>



    <div class="dash_card_container">
        <div class="card_in" id="dash_color_red">
            <div class="dash_card_value dash_dark">Courses</div>
            <div class="dash_card_value"><?php echo $totalcourse;?></div>
            <div class="dash_card_value"><a href="admin_course.php">View</a></div>
        </div>
        <div class="card_in" id="dash_color_green">
             <div class="dash_card_value dash_dark">Student</div>
            <div class="dash_card_value"><?php echo $totalstudent;?></div>
            <div class="dash_card_value"><a href="admin_student.php">View</a></div>
        </div>
        <div class="card_in" id="dash_color_blue">
             <div class="dash_card_value dash_dark">Course Sold</div>
            <div class="dash_card_value"><?php echo $totalsold;?></div>
            <div class="dash_card_value"><a href="admin_sellreport.php">View</a></div>
        </div>
    </div>


    <?php 

    $sql = "SELECT * FROM courseorder";
    $result = $conn->query($sql);
    if($result->num_rows > 0)
    {
    ?>


    <div class="dash_course_order">
        Course Ordered
    </div>

<!-- table -->

    <table class="table">
        <thead class="dash_table">
          <tr>
            <th scope="col">Order ID</th>
            <th scope="col">Course ID</th>
            <th scope="col">Students Emails</th>
            <th scope="col">Order Date</th>
            <th scope="col">Amount</th>
            <th scope="col">Remove Order</th>
          </tr>
        </thead>
        <tbody>

        
    <?php  while($row = $result->fetch_assoc()){
           
           echo '<tr>';
           echo '<th scope="row">'.$row['order_id'].'</th>';
           echo '<td>'.$row['course_id'].'</td>';
           echo '<td class="email_stu">'.$row['user_email'].'</td>';
           echo '<td>'.$row['order_date'].'</td>';
           echo '<td>'.$row['amount'].'</td>';
 
           echo '<td>
                    <form method="POST" class="d-inline">
                     <input type="hidden" name="co_id" value='.$row["co_id"].'>
                     <button type="submit" name ="delete" value="delete" class="course_btn">
                         <i class="fas fa-trash-alt"></i></button>
                   </form>
                 </td>';
           echo '</tr>';
        } ?>
          
        </tbody>
      </table>

      <?php  
    }
      else {
        echo "<div style='font-size:2rem; font-weight: bold; color: red'> <center>No Data Found</center></div>";
      }
      ?>


      <!-- course delete  -->

      <?php
        if(isset($_REQUEST['delete'])){
          $sql = "DELETE FROM courseorder WHERE co_id = {$_REQUEST['co_id']}";
        
          if($conn->query($sql) == TRUE){
            echo '<meta http-equiv="refresh" content="0;URL=?deleted" />';
          } else {
            echo "Unable to Delete Data";
                        echo '<meta http-equiv="refresh" content="0;URL=?unable_to_delete" />';
          }
          }
        ?>





    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>