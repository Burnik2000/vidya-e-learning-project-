<?php 
    if(!isset($_SESSION)){
      session_start();
    }
    
    if(isset($_SESSION['is_admin_login'])){
      $adminEmail = $_SESSION['admin'];
    }else{
      header('location:../index.php');
    }

        include('admindata/course_db.php');

        $sql = "SELECT * FROM admin WHERE email = '$adminEmail'";

        $result = mysqli_query($conn, $sql) or die("query faild");

        $rows = mysqli_fetch_assoc($result);
    ?>
    





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">

    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="admin_css/admin_profile.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <!-- navbar -->
    
    <div class="admin_nav">
    <a href="admin_dashboard.php"> <div class="admin_navlink"> Dashboard </div></a>
    <a href="admin_course.php"> <div class="admin_navlink"> Course </div></a>
    <a href="admin_lessons.php"><div class="admin_navlink"> Lessons </div></a>
    <a href="admin_student.php"><div class="admin_navlink"> Students </div></a>
    <a href="admin_sellreport.php"><div class="admin_navlink"> Sell Report </div></a>
    <a href="admin_payment.php"><div class="admin_navlink"> Payment Status </div></a>
    <a href="admin_feedback.php"><div class="admin_navlink"> Feedback </div></a>
    <a href="help_center.php"><div class="admin_navlink"> Help Center </div></a>
    <a href="admin_contact.php"><div class="admin_navlink"> <i class="fas fa-envelope"></i></div></a>
    <a href="admin_profile.php"><div class="admin_navlink active"><i class="fas fa-user-circle"></i></div></a>
    <a href="admindata/logout.php"><div class="admin_navlink"> <i class="fas fa-sign-out-alt"></i> </div></a>
    </div>


    <div class="admin_container">
        <div class="admin_image">
            <img src="<?php echo $rows['image']?>" alt="admin Profile">
        </div>
        <div class="admin_profile">
            <div class="admin_details">
                <div class="admin_name">
                    <div class="_name"><?php  echo $rows['name'] ?></div>
                    <div class="_occu"><?php echo $rows['occupation'] ?></div>
                    <div class="_email"><?php echo $rows['email'] ?></div>
                </div>
                <div class="admin_id">  
                    <div>ID</div>
                    <div><?php echo $rows['id'] ?></div>
                </div>
            </div>
        </div>
    </div>



    <div class="dash_course_order">
        List Of Admin
    </div>



    <?php 

    $sql = "SELECT * FROM admin";
    $results = $conn->query($sql);
    if($results->num_rows > 0)
    {

    ?>

<!-- table -->

    <table class="table align-middle">
        <thead class="dash_table">
          <tr>
            <th scope="col">Admin ID</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Occupation</th>
            <th scope="col">Image</th>
            <th scope="col">Social</th>
            <th scope="col">Edit / Remove</th>
          </tr>
        </thead>
        <tbody>

        <?php  while($row = $results->fetch_assoc()){

          echo '<tr>';
          echo '<th scope="row">'.$row['id'].'</th>';
          echo '<td>'.$row['name'].'</td>';
          echo '<td class="email_stu">'.$row['email'].'</td>';
          echo '<td>'.$row['occupation'].'</td>';
          echo '<td><img style = "height:8rem;" src="'.$row['image'].'" alt="Image"></td>';
          echo '<td><a target="_blank" style = "color:#000;" href="'.$row['social'].'"><i class="fab fa-linkedin-in"></i></a></td>';

          echo '<td>
                  <form action="edit_admin.php" method="POST" class="d-inline" id="edit_form">
                     <input type="hidden" name="s_id" value='.$row["id"].'>
                     <button type="submit" name ="view" value="view" class="course_btn">
                     <a href="#" data-bs-toggle="modal" data-bs-target="#edit_admin"><i class="fas fa-pen-square"></i></a></button>
                      </form>';


          echo '  <form method="POST" class="d-inline">
                    <input type="hidden" name="a_id" value='.$row["id"].'>
                    <button type="submit" name ="delete" value="delete" class="course_btn">
                        <i class="fas fa-trash-alt"></i></button>
                  </form>
                </td>';
          echo '</tr>';

          } ?>
        </tbody>
      </table>

      <?php  
    }
      else {
        echo "<div style='font-size:2rem; font-weight: bold; color: red'> <center>Please Add Admin</center></div>";
      }
      ?>

      <p class="add_course"><a href="#" data-bs-toggle="modal" data-bs-target="#add_admin"><i class="fas fa-plus-square"></i></a></p>


      <!-- admin delete  -->

      <?php
        if(isset($_REQUEST['delete'])){
          $sql = "DELETE FROM admin WHERE id = {$_REQUEST['a_id']}";
        
          if($conn->query($sql) == TRUE){
            echo '<meta http-equiv="refresh" content="0;URL=?deleted" />';
          } else {
            echo "Unable to Delete Data";
            echo '<meta http-equiv="refresh" content="0;URL=?unable_to_delete" />';
          }
          }
        ?>

  <!-- add admin -->

      <div class="modal fade" id="add_admin" tabindex="-1" aria-labelledby="add_adminLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
              <?php include('add_admin.php');?>
            </div>
          </div>
        </div>
      </div>

  <!-- edit admin -->

      <div class="modal fade" id="edit_admin" tabindex="-1" aria-labelledby="edit_adminLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
              <?php include('edit_admin.php');?>
            </div>
          </div>
        </div>
      </div>

    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>