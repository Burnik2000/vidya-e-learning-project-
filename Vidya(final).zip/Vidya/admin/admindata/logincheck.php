<?php
if(!isset($_SESSION)){
	session_start();
	}

$con = mysqli_connect('localhost', 'root' );
if($con){
	echo "conenction successful";
}else{
	echo "no connection";
}

$db = mysqli_select_db($con, 'vidya');

if(isset($_POST['submit'])){
	$adminemail = $_POST['email'];
	$password = $_POST['pass'];

	$sql = " select * from  admin where email='$adminemail' and password='$password' ";
	$query = mysqli_query($con,$sql);

	$row = mysqli_num_rows($query);
		if($row == 1){
			echo "login successful";
			$_SESSION['is_admin_login'] =true;
			$_SESSION['admin'] = $adminemail;
			$_SESSION['password'] = $password;
			header('location:../admin_dashboard.php');
		}else{
			echo "login failed";
			header('location:../../index.php');
		}

}


?>