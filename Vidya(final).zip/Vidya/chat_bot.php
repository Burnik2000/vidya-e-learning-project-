<div class="card">
      <div class="card-body messages-box">
        <ul class="list-unstyled messages-list">
          <?php
            $res=mysqli_query($con,"select * from message");
            if(mysqli_num_rows($res)>0){
              $html='';
              while($row=mysqli_fetch_assoc($res)){
                $message=$row['message'];
                $added_on=$row['added_on'];
                $strtotime=strtotime($added_on);
                $time=date('h:i A',$strtotime);
                $type=$row['type'];
                if($type=='user'){
                  $class="messages-me";
                  $imgAvatar="user-bot.png";
                  $name="Me";
                }else{
                  $class="messages-you";
                  $imgAvatar="chat-bot.png";
                  $name="Vidya";
                }
                $html.='<li class="'.$class.' clearfix"><span class="message-img"><img src="img/'.$imgAvatar.'" class="avatar-sm rounded-circle"></span><div class="message-body clearfix"><div class="message-header"><strong class="messages-title">'.$name.'</strong> <small class="time-messages text-muted"><span class="fas fa-time"></span> <span class="minutes">'.$time.'</span></small> </div><p class="messages-p">'.$message.'</p></div></li>';
              }
              echo $html;
            }else{
              ?>
                      <li class="messages-you clearfix">
                        <span class="message-img">
                          <img src="img/chat-bot.png" class="avatar-sm rounded-circle"></span>
                          <div class="message-body clearfix">
                            <div class="message-header">
                              <strong class="messages-title">Vidya<sup>beta</sup></strong>
                              <small class="time-messages text-muted"><span class="fas fa-time"></span> <span class="minutes">     </span></small>
                               </div>
                               <p class="messages-p">Welcome to vidya.<br>How can I help you?</p>
                              </div>
                        </li>
                      <?php
            }
            ?>

        </ul>
      </div>
      <div class="card-header">
        <div class="input-group">
          <input id="input-me" type="text" name="messages" class="form-control input-sm"
            placeholder="Type your message here..." />
          <span class="input-group-append">
            <button id="chat-btn" class="btn-bot" onclick="send_msg()"><i class="fas fa-arrow-circle-right"></i></button>
          </span>
        </div>
      </div>
    </div>