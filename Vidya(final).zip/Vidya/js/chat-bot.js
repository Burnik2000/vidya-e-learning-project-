function getCurrentTime(){
 var now = new Date();
 var hh = now.getHours();
 var min = now.getMinutes();
 var ampm = (hh>=12)?'PM':'AM';
 hh = hh%12;
 hh = hh?hh:12;
 hh = hh<10?'0'+hh:hh;
 min = min<10?'0'+min:min;
 var time = hh+":"+min+" "+ampm;
 return time;
}
function send_msg(){
 jQuery('.start_chat').hide();
 var txt=jQuery('#input-me').val();
 var html='<li class="messages-me clearfix"><span class="message-img"><img src="img/user-bot.png" class="avatar-sm rounded-circle"></span><div class="message-body clearfix"><div class="message-header"><strong class="messages-title">Me</strong> <small class="time-messages text-muted"><span class="fas fa-time"></span> <span class="minutes">'+getCurrentTime()+'</span></small> </div><p class="messages-p">'+txt+'</p></div></li>';
 jQuery('.messages-list').append(html);
 jQuery('#input-me').val('');
 if(txt){
   jQuery.ajax({
     url:'database/get_bot_message.php',
     type:'post',
     data:'txt='+txt,
     success:function(result){
       var html='<li class="messages-you clearfix"><span class="message-img"><img src="img/chat-bot.png" class="avatar-sm rounded-circle"></span><div class="message-body clearfix"><div class="message-header"><strong class="messages-title">Vidya</strong> <small class="time-messages text-muted"><span class="fas fa-time"></span> <span class="minutes">'+getCurrentTime()+'</span></small> </div><p class="messages-p">'+result+'</p></div></li>';
       jQuery('.messages-list').append(html);
       jQuery('.messages-box').scrollTop(jQuery('.messages-box')[0].scrollHeight);
     }
   });
 }
}

var input = document.getElementById("input-me");
input.addEventListener("keyup", function(event) {
if (event.keyCode === 13) {
 event.preventDefault();
 document.getElementById("chat-btn").click();
}
});