$(window).scroll(function () {
    $('div').toggleClass('scrolled', $(this).scrollTop() > 50);
  });