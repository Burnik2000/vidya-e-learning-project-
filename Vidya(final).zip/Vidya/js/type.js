        var typed = new Typed('.tag-type', {
            // Waits 1000ms after typing "First"
            strings: ['Welcome To Vidya','Learn In Your Own Language','अपनी भाषा में सीखें', 'নিজের ভাষায় শিখুন'],
            typeSpeed:50,
            backSpeed:25,
            loop:true,
        });
