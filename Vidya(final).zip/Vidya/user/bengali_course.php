<!-- database link -->

<?php
  if(!isset($_SESSION)){
    session_start();
  }
    date_default_timezone_set('Asia/Kolkata');
    include('../database/connection.php');
  ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bengali Courses</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="user_css/all_course.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>


    <!-- navbar -->
   
    <div class="user_nav">

    <a href="../index.php"><div class="user_navlink">  <i class="fas fa-home"></i> Home </div></a>
    <a href="all_course.php"><div class="user_navlink">  All Courses </div></a>
    <a href="english_course.php"><div class="user_navlink"> English Courses </div></a>
    <a href="hindi_course.php"><div class="user_navlink"> Hindi Courses </div></a>
    <a href="bengali_course.php"><div class="user_navlink active"> Bengali Courses </div></a>
    <a href="user_dash.php"><div class="user_navlink"> <i class="fas fa-user-circle"></i> </div></a>
    </div>


<div class="grid_container">



  <!-- Courses Start -->


    <!-- Courses part 1 Start -->

    <?php
        $sql = "SELECT * FROM course WHERE course_language = 'bengali'";
        $result = $con->query($sql);
            if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                $course_id = $row['course_id'];
                echo '
                
                <div class="grid_item">
                <a href="course_details.php?course_id='.$course_id.'">
              
                <div class="course_out_bg">
                    <div class="course_in_bg">
                    <div class="course_in_img_bg">
                        <img src="'.$row['course_image'].'" alt="Course image">
                    </div>
                    <div class="course_desc">
                        <span class="course_title">'.$row['course_name'].'</span>
                        <p>'.$row['course_language'].' <span>'.$row['course_duration'].'</span></p>

                        <div class="course_credit_price">
                        <div>by '.$row['course_author'].'</div>
                        <div>Price - <span class="price_drop"> &#8377;'.$row['course_original_price'].'</span> &#8377;'.$row['course_selling_price'].'</div>
                        </div>
                    </div>
                    </div></a>

                    <div class="course_view_enroll">

                    <a  href="course_details.php?course_id='.$course_id.'">
                    <div class="btn_view">
                        View Course
                    </div></a>

                    
               

                   
                </div>
                </div>
                </div>
                ';
            }
            }
            ?>               
            <!-- course section 1 stop -->

</div>


<div style="width: auto; height: 5rem; background: rgba(0, 0, 0, 0);"></div>



    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>