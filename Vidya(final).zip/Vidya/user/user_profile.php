<?php 
include('../database/controllerUserData.php');

    if(!isset($_SESSION)){
            session_start();
        }
    
        if(isset($_SESSION['email'])){
            $useremail = $_SESSION['email'];
            }else{
            header('location:../index.php');
            }



    //Update Student details 
    
    if(isset($_REQUEST['userupdate'])){

        // checking for empty fields 

    if(($_REQUEST['user_id'] == "") ||
     ($_REQUEST['user_name'] == "") ||
     ($_REQUEST['user_email'] == "") || 
     ($_REQUEST['user_password'] == "") || 
     ($_REQUEST['user_occupation'] == "")
     ){
         //if filds missing
         $msg = '<div class="fill_error">Fill All Fields</div>';
         echo '<meta http-equiv="refresh" content="0;URL=?fill_all_fields" />';
     }
     else {
          $user_id = $_REQUEST['user_id'];
          $user_name = $_REQUEST['user_name'];
          $user_email = $_REQUEST['user_email'];
          $user_password = $_REQUEST['user_password'];
          $user_occupation = $_REQUEST['user_occupation'];
          $user_img = $_FILES['user_img']['name'];
          $user_img_temp = $_FILES['user_img']['tmp_name'];
          $img_folder = '../img/user_image/'.$user_img;
          move_uploaded_file($user_img_temp, $img_folder);
          $encpass = password_hash($user_password, PASSWORD_BCRYPT);


          $sql = "UPDATE user SET name = '$user_name', email = '$user_email', password= '$encpass', occupation='$user_occupation', image= '$img_folder' WHERE id = '$user_id'";

          if($con->query($sql) == TRUE){

            //submit success
             $msg = '<div class="add_success">Update Succesfully</div>';
             echo '<meta http-equiv="refresh" content="0;URL=?updated" />';
         }
         else{
             $msg = '<div class="fill_error">Unable to Update</div>';
             echo '<meta http-equiv="refresh" content="0;URL=?fail_to_update" />';
         }
     }
    }
?>





<!DOCTYPE html>
<html>
<head>
	<title>Edit Profile</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="user_css/user_dash.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="user_css/user_profile.css">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>



    <!-- navbar -->
    
    <div class="user_nav">
    <a href="user_dash.php"><div class="user_navlink">  Dashboard </div></a>
    <a href="user_course.php"><div class="user_navlink"> My Course </div></a>
    <a href="all_course.php"><div class="user_navlink"> All Course </div></a>
    <a href="user_paymentStatus.php"><div class="user_navlink"> Payment Status </div></a>
    <a href="user_feedback.php"><div class="user_navlink"> Feedback </div></a>
    <a href="user_profile.php"><div class="user_navlink active"> <i class="fas fa-user-circle"></i> </div></a>
    <a href="../logout-user.php"><div class="user_navlink"> <i class="fas fa-sign-out-alt"></i></div></a>
    </div>





    <?php
        $useremail = $_SESSION['email'];
        $userpassword = $_SESSION['password'];

            $sql = "SELECT * FROM user WHERE email = '$useremail'";
            $run_Sql = mysqli_query($con, $sql);

                $rows = mysqli_fetch_assoc($run_Sql);
    ?>



<div class="main_body">

    <div class="edit_user_main">
        <div class="edit_user_head">Edit Profile</div>



        <div class="edit_user_upper">
            <form class="edit_user_login" action="" method="POST" enctype="multipart/form-data">
                
                <input class="edit_user_textbox form-control" type="text" id="user_id" name="user_id" placeholder="Type your admin id here..." value="<?php echo $rows['id'] ?>" readonly>

                <input class="edit_user_textbox form-control" type="email" id="user_email" name="user_email" placeholder="Type your admin email here..." value="<?php echo $rows['email'] ?>" readonly>
                
                <input class="edit_user_textbox form-control" type="text" id="user_name" name="user_name" placeholder="Type your admin name here..." value="<?php echo $rows['name'] ?>" required>
                
                <input class="edit_user_textbox form-control" type="password" id="user_password" name="user_password" placeholder="Type your admin password here..." value="" required>

                <input class="edit_user_textbox form-control" type="text" id="user_occupation" name="user_occupation" placeholder="Type your admin occupation here..." value="<?php echo $rows['occupation'] ?>" required>
                
                
                <input type="file" class="edit_user_textbox form-control" id="user_img" name="user_img" required>
                
                <img style="height:10rem; border-radius:1rem;" src="<?php echo $rows['image'] ?>" alt="image">

                <input class="edit_user_submit" id="userupdate" type="submit" value="Update" name="userupdate">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>
    
        <p class="delete_profile"><a href="#" data-bs-toggle="modal" data-bs-target="#delete_user"><i class="fas fa-trash-alt"></i></a>
    </div>


        <!-- delete feedback  -->


    <div class="modal fade" id="delete_user" tabindex="-1" aria-labelledby="delete_userLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
                <div class="delete_user">
                    <p>Permanetly Delete your account?</p>
                    <form method="POST" class="d-inline">
                        <button type="submit" name ="delete" value="delete" class="delete_btn">Delete</button>
                    </form>
                </div>
            </div>
          </div>
        </div>
      </div>


      
      <!-- user delete  -->

      <?php
        if(isset($_REQUEST['delete'])){
          $sql = "DELETE FROM user WHERE id = {$rows['id']}";
        
          if($con->query($sql) == TRUE){
            echo '<meta http-equiv="refresh" content="0;URL=?deleted" />';
            header('location:../index.php');
          } else {
            echo "Unable to Delete Data";
             echo '<meta http-equiv="refresh" content="0;URL=?unable_to_delete" />';
          }
          }
        ?>


           

         
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>
</html>


